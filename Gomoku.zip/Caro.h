#ifndef _Caro_H_
#define _Caro_H_

#include <iostream>
#include <windows.h>
#include <conio.h>
#include <stdio.h>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <string.h>
#include <fstream>
#include <Key.h>
//#include <Menu.h>

#define CellWidth 4   
#define CellHeight 2   
#define ConsoleWidth 170
#define ConsoleHeight 40
#define TitleHeight 5
#define TitleWidth 30

using namespace std;

struct User
		{
			string Name ;
			int Won = 0;
			int Color;
			int nChecker;
			char Checker;
		};


class Caro
{ 
	public:
		// Declare properties
		int Left;
  		int Top;
  		int NodeNumber; 
  		int PlayUser; 
		int CellNumber;  
		int Win = 0;
		int ThinkPlayer;
		int ThinkPC;
		int FirstCol;
		int FirstRow;
		char* FileName;
		
		
		struct History
			{
				int Row;
				int Col;
			};
		History	UndoBoard[400];
		History HVMS[4][2];
		
		User U1;
		User U2;
		
		
		
	private:
		int Width;
  		int Height;
		int SLeft;
  		int STop;
  		int pLeft;
  		int pTop;
		int SRow;
  		int SCol;
  		int** Board;
  		int IndexHistory = 0;
  		int Comp;
  		
  		

	public:
		// Declare construtor & Destructor
		Caro(int pNodeNumber, int pCellNumber, User P1, User P2, int pComp, char* pFileName);
	   ~Caro(void);
	   
		// Declare public method
		void Draw_Caro();
		void DrawBoard();
		int Play();
		bool IsWinner();
		void gotoXY(int x, int y);
		void Start();
		void DrawTitle(int x, int y);
		void PlayerInfo();
		void clrscr();
		void SetColor(WORD color);
		bool IsDraw();
		void SaveFile(char* FileName);
		void ContinueFile(char* FileName);
		void EasyPvC();
		void PlayerBox();
		
		int CheckHorizontally(int PlayUser);
		int CheckVertically(int PlayUser);
		int CheckMainDiagonal(int PlayUser);
		int CheckSubDiagonal(int PlayUser);
		
		int ComparePvC(int a, int b, int c, int d, int &Think);
		void SwitchThinking();
		void AttackRandom(int &FirstRow,int &FirstCol);
		void AttackNextMove(int FirstRow,int FirstCol);
		void Defense(int ThinkPlayer);
};

void Caro::clrscr()
{
	system("cls");
}

// Constructor
Caro::Caro(int pNodeNumber, int pCellNumber, User P1, User P2, int pComp, char* pFileName)
{
	CellNumber = pCellNumber;
	NodeNumber = pNodeNumber;
	Width = CellNumber * CellWidth;
	Height = CellNumber * CellHeight;
	pLeft = ( ConsoleWidth - Width ) / 2;
	pTop = ( ConsoleHeight - Height ) / 2;
	SLeft = pLeft + 2;
	STop = pTop + 1;
	Top = pTop;
	Left = pLeft;
	PlayUser = 1;
	Board = new int*[CellNumber+1];
		for ( int i = 0; i < CellNumber; ++i )
			Board[i] = new int[CellNumber];
	U1 = P1;
	U2 = P2;
	Comp = pComp;
	FileName = pFileName;
};

//Destructor
Caro::~Caro(void)
{
	for ( int i = 0; i < CellNumber; ++i )
	{
		delete[] Board[i];
	}
	
	delete[] Board;

};

// Public method
void Caro::gotoXY(int x, int y) 
{ 
    COORD pos = {x, y};
    HANDLE output = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleCursorPosition(output, pos);
}

void Caro::DrawTitle(int x, int y)
{
	SetColor(9);
	while(1)
	{
		for ( int j = 1; j <= TitleHeight; ++j )
		{
			gotoXY(x, y);
			switch (j)
			{
				case 1:
				{
					for ( int i = 1; i <= TitleWidth; ++i )
						if ((i==2)||(i==3)||(i==7)||(i==8)||(i==12)||(i==14)||(i==18)||(i==19))
							putchar(205);
						else
							if ((i==1)||(i==6)||(i==11)||(i==17))
								putchar(201);
							else
								if ((i==9)||(i==20)||(i==15))
									putchar(187);
								else
									if ((i==22)||(i==27)||(i==30))
										putchar(203);
									else
										if (i==13)
											putchar(203);
										else 
											if (i==25) 
												cout << "x";
											else
												cout << " ";
					break;	
				}
	 			case 2:
	 			{
	 				for ( int i = 1; i <= TitleWidth; ++i )
						if (i==24) 
							cout << "0";
						else
							if ((i==1)||(i==6)||(i==9)||(i==11)||(i==13)||(i==15)||(i==17)||(i==20)||(i==22)||(i==27)||(i==30)) 
								putchar(186);
							else
								cout << " ";
					break;
				}
				case 3:
				{
					for ( int i = 1; i <= TitleWidth; ++i )
						if ((i==1)||(i==6)||(i==9)||(i==11)||(i==13)||(i==15)||(i==17)||(i==20)||(i==22)||(i==27)||(i==30))
							putchar(186);
						else
							if (i==4)
								putchar(187);
							else
								if (i==3)
									putchar(205);
								else
									if (i==23)
										cout << "x";
									else
										cout << " ";
					break;
				}	
				case 4:
				{
					for ( int i = 1; i <= TitleWidth; ++i )
						if ((i==1)||(i==4)||(i==6)||(i==9)||(i==11)||(i==15)||(i==17)||(i==20)||(i==22)||(i==27)||(i==30))
							putchar(186);
						else
							if (i==24)
								cout << "0";
							else
								cout << " ";
					break;
				}
				case 5:
				{
					for ( int i = 1; i <= TitleWidth; ++i )
						if ((i==1)||(i==6)||(i==17)||(i==27))
							putchar(200);
						else
							if ((i==4)||(i==9)||(i==20)||(i==30))
								putchar(188);
							else
								if ((i==2)||(i==3)||(i==7)||(i==8)||(i==18)||(i==19)||(i==28)||(i==29))
									putchar(205);
								else
									if ((i==22)||(i==11)||(i==15))
										putchar(202);
									else
										if (i==25)
											cout << "x";
										else 
											
												cout << " ";
					break;
				}
			}
			++y;
		};
		break;
	}
}

void Caro::DrawBoard()
{
	SetColor(7);
		for ( int i = 0; i <= Height; ++i )
	{
		gotoXY(Left,Top+i);
		if ( i == 0 ) 
			for ( int j = 0; j <= Width; ++j ) 
				if ( j == 0 ) putchar (218);
				else 	
					if ( j == Width ) putchar(191);
					else
						if ( j % CellWidth == 0 ) putchar(194);
						else putchar(196);
		else 
			if ( i == Height )
				for ( int j = 0; j <= Width; ++j )
					if ( j == 0 ) putchar(192);
					else
						if ( j == Width ) putchar(217);
						else 
							if ( j % CellWidth == 0 ) putchar(193);
							else putchar(196);
			else
				if ( i % CellHeight == 0 )
					for ( int j = 0; j <= Width; ++j )
						if ( j == 0 ) putchar(195);
						else
							if ( j == Width ) putchar(180);
							else
								if ( j % CellWidth == 0 ) putchar(197);
								else putchar(196); 
		 		else 
		 			for (int j = 0; j <= Width; ++j)
		 				if ( j % CellWidth == 0 ) putchar(179);
		 				else cout << " ";
	}
	
	// Clear Board
	for ( int i = 0; i < CellNumber; ++i )
	{	
		for ( int j = 0; j < CellNumber; ++j )
		{
			Board[i][j] = 0; 
		}
	}
	
	DrawTitle(135,1);
	Console();
}

void Caro::SetColor(WORD color = 7) 
{
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), color);
}

int Caro::Play()
{
	int _Loop, X, Y;
	int _Return = 1;
	
	X = SLeft + SCol*CellWidth; Y = STop + SRow*CellHeight; 
	gotoXY(X,Y);
	_Loop = 1;
	while (_Loop) 
	{
		int Key; 
		
		if ((Comp == 1) && (PlayUser == 2))
			Key = 200;				
		else
			Key = getch();
			
		switch (Key)
		{
			case 13: // Enter
			case 200: //For PvC Mode
				if (Board[SRow][SCol] == 0)
				{
					Board[SRow][SCol] = PlayUser; 
					UndoBoard[IndexHistory].Col = SCol;
					UndoBoard[IndexHistory].Row = SRow;
					++IndexHistory;
					EnterButton( PlayUser == 1 ? U1.Color : U2.Color );
				}
				else
				{
					PlayUser = (PlayUser == 1 ? 2 : 1);
					EnterButton( PlayUser == 1 ? U2.Color : U1.Color );
				}
				DrawSpacebar(); 
				UpButton();
				DownButton();
				LeftButton();
				RightButton();
				_Loop = 0;  
				break; 
			case 32:  //Spacebar undo
				if (IndexHistory > 0)
				{
					SRow = UndoBoard[IndexHistory-1].Row;
					SCol = UndoBoard[IndexHistory-1].Col;
					Board[SRow][SCol] = 0;			
					--IndexHistory;	
					
					if (Comp == 1)
					{
						SRow = UndoBoard[IndexHistory-1].Row;
						SCol = UndoBoard[IndexHistory-1].Col;
						Board[SRow][SCol] = 0;				
						--IndexHistory;	
					}
					
				}
				EnterButton();
				DrawSpacebar(PlayUser==2 ? U1.Color : U2.Color ); 
				UpButton();
				DownButton();
				LeftButton();
				RightButton();
				_Loop = 0; 
				break; 
			case 27:   // Escape
				_Return = 0;
				_Loop = 0;
				break;
			case 75:   // Left 
				if ( SCol > 0 )
					{
						DrawSpacebar(); 
						UpButton();
						DownButton();	
						LeftButton( PlayUser==1 ? U1.Color : U2.Color );	
						RightButton();
						EnterButton();
						SCol--;
					}
				break;	
			case 77:   // Right
				if ( SCol < CellNumber - 1 )
					{
						DrawSpacebar(); 
						UpButton();
						DownButton();
						LeftButton();
						RightButton( PlayUser==1 ? U1.Color : U2.Color );
						EnterButton();
						SCol++;
					}
				break;
			case 72:   // Up
				if ( SRow > 0 )
					{
						DrawSpacebar(); 
						UpButton( PlayUser==1 ? U1.Color : U2.Color );
						DownButton();
						LeftButton();
						RightButton();
						EnterButton();
						SRow--;
					}
				break;
			case 80:   // Down
				if ( SRow < CellNumber - 1 )
				{
					DrawSpacebar(); 
					UpButton();
					DownButton( PlayUser==1 ? U1.Color : U2.Color );
					LeftButton();
					RightButton();
					EnterButton();
					SRow++;
				}
				break;
			case 83:
			case 115:
				{
					SaveFile(FileName);
				}
				break;
		}
		X = SLeft + SCol*CellWidth; Y = STop + SRow*CellHeight; 
		gotoXY(X,Y);
	}
	return _Return;
}

void Caro::Draw_Caro()
{
	for ( int i = 0; i < CellNumber; ++i )
		for ( int j = 0; j < CellNumber; ++j )
		{
			gotoXY ( (pLeft + j*CellWidth + 2),(i*CellHeight+1 +pTop) );
			switch(Board[i][j])
			{
				case 0:
					cout << " ";
					break;
				case 1:
					SetColor(U1.Color);
					cout << U1.Checker;
					break;
					
				case 2:
					SetColor(U2.Color);
					cout << U2.Checker;
					break;
			}
		} 
}

bool Caro::IsWinner()
{	
	bool _Return = false; int SeleNumber;
	//-- Check horizontal (Fix SRow)
	SeleNumber = (Board[SRow][SCol] == PlayUser ? 1 : 0);
	if (SCol > 0)
	{
		for (int i = SCol - 1; i>=0; --i)
		{
			if (Board[SRow][i] == PlayUser) 
			{
				SeleNumber++;
			}	
			else
			{
				break;
			}
		}
	}
	if (SCol < CellNumber - 1)
	{
		for (int i = SCol + 1; i < CellNumber; ++i)
		{
			if (Board[SRow][i] == PlayUser) 
			{
				SeleNumber++;
			}	
			else
			{
				break;
			}
		}
	}
	_Return = (SeleNumber >= NodeNumber);
	//-- Check vertical (Fix SCol)
	if (!_Return )
	{
		SeleNumber = (Board[SRow][SCol] == PlayUser ? 1 : 0);
		if (SRow > 0)
		{
			for (int i = SRow - 1; i>=0; --i)
			{
				if (Board[i][SCol] == PlayUser) 
				{
					SeleNumber++;
				}	
				else
				{
					break;
				}
			}
		}
		if (SRow < CellNumber - 1)
		{
			for (int i = SRow + 1; i<CellNumber; ++i)
			{
				if (Board[i][SCol] == PlayUser) 
				{
					SeleNumber++;
				}	
				else
				{
					break;
				}
			}
		}
		
	}

	_Return = (SeleNumber >= NodeNumber);
	//-- Check the first diagonal
	if (!_Return )
	{
		SeleNumber = (Board[SRow][SCol] == PlayUser ? 1 : 0);
		if ((SCol > 0) && (SRow > 0))
		{
			int i = SRow-1;
			int j = SCol-1;
			int k = (i>j ? j : i);
			for (k; k>=0; --k)
			{
				if (Board[i][j] == PlayUser) 
				{
					SeleNumber++;
					--i; --j;
				}	
				else
				{
					break;
				}
			}
		}
		if ((SCol < CellNumber - 1) && (SRow < CellNumber - 1))
		{
			int i = SRow+1;
			int j = SCol+1;
			int k = (i>j ? i : j);
			for (k; k<CellNumber; ++k)
			{
				if (Board[i][j] == PlayUser) 
				{
					SeleNumber++;
					++i; ++j;
				}	
				else
				{
					break;
				}
			}
		}
	}
	_Return = (SeleNumber >= NodeNumber);
	//-- Check the second diagonal
	if (!_Return )
	{
		SeleNumber = (Board[SRow][SCol] == PlayUser ? 1 : 0);
		if ((SCol > 0 ) && (SRow < CellNumber - 1))
		{
			int i = SRow + 1;
			int j = SCol - 1;
			for (int k=0; k<CellNumber; ++k)
			{
				if (Board[i][j] == PlayUser) 
				{
					SeleNumber++;
					++i; --j;
					if (j<0 || i ==CellNumber) {break;}
				}	
				else
				{
					break;
				}
			}
		}
		if ((SRow > 0 ) && (SCol < CellNumber - 1))
		{
			int i = SRow - 1;
			int j = SCol + 1;
			for (int k=0; k<CellNumber; ++k)
			{
				if (Board[i][j] == PlayUser) 
				{
					SeleNumber++;
					--i; ++j;
					if (i<0 || j ==CellNumber) {break;}
				}	
				else
				{
					break;
				}
			}
		}
	}
	_Return = (SeleNumber >= NodeNumber);
	return _Return;
}

bool Caro::IsDraw()
{
	bool lReturn = true; 
	
	for ( int i = 0; i < CellNumber; ++i )
		{
			for ( int j = 0; j < CellNumber; ++j )
				if (Board[i][j] == 0)
					 {
				 		lReturn = false;
				 		break;
					 }
			if (!lReturn) 
				break;
		}
	
	return lReturn;
}

void Caro::SaveFile(char* FileName)
{
	ofstream GomokuHistory;
	GomokuHistory.open(FileName);
	
	GomokuHistory << U1.Name << endl;
	GomokuHistory << U1.Color << endl;
	GomokuHistory << U1.Checker << endl;
	GomokuHistory << U1.Won << endl;
	
	GomokuHistory << U2.Name << endl;
	GomokuHistory << U2.Color << endl;
	GomokuHistory << U2.Checker << endl;
	GomokuHistory << U2.Won << endl;
	
	GomokuHistory << CellNumber << endl;
	
	for ( int i = 0; i < CellNumber; ++i )
	{
		for ( int j =0; j < CellNumber; ++j )
			GomokuHistory << Board[i][j];
		GomokuHistory << endl;
	}
		
	GomokuHistory.close();
}

void Caro::ContinueFile(char* FileName)
{
	char BoardTemp[CellNumber][CellNumber];
	
	ifstream Continue (FileName);
	Continue.is_open();
		
	Continue >> U1.Name;
	Continue >> U1.Color;
	Continue >> U1.Checker;
	Continue >> U1.Won;
	
	Continue >> U2.Name;
	Continue >> U2.Color;
	Continue >> U2.Checker;
	Continue >> U2.Won;
	
	Continue >> CellNumber;
	
	for ( int i = 0; i < CellNumber; ++i )
		{
			for ( int j = 0; j < CellNumber; ++j )
				Continue >> BoardTemp[i][j];
		}
		
	for ( int i = 0; i < CellNumber; ++i )
		{
			for ( int j = 0; j < CellNumber; ++j )
				switch (BoardTemp[i][j])
					{
						case '0':
							Board[i][j] = 0;
							break;
						case '1':
							Board[i][j] = 1;
							break;
						case '2':
							Board[i][j] = 2;
							break;	
					}
		}	
		
	Continue.close();
}


int Caro::CheckHorizontally(int PlayUser)
{
	int hNumber = 1;
	
	if (Board[SRow][SCol] == PlayUser)
	{
			//Right
		 for (int i = 1; SCol + i < CellNumber; ++i)
		 {
		 	if (Board[SRow][SCol+i] == 1)
					++hNumber;
		 	else
				{
					HVMS[0][0].Row = SRow;
					HVMS[0][0].Col = SCol + i- 1;
					break;
				}		 	
		 }
		 
		//Left 
		 for (int i = 1; SCol - i >= 0; ++i)
		 {
		 	if (Board[SRow][SCol-i] ==  1)
		 			++hNumber;
		 	else
		 		{
		 			HVMS[0][1].Row = SRow;
		 			HVMS[0][1].Col = SCol -i + 1;
		 			break;
				}
		 		
		 }
	}
	
	 return hNumber;
}

int Caro::CheckVertically(int PlayUser)
{
	int vNumber = 1;
	
	if (Board[SRow][SCol] == PlayUser)
	{
		//Up
		for (int i = 1; SRow - i >= 0; ++i)
		{
			if (Board[SRow-i][SCol] == 1)
				++vNumber;
			else
				{
					HVMS[1][0].Row = SRow - i + 1;
					HVMS[1][0].Col = SCol;
					break;
				}
		}
		
		//Down
		for (int i = 1; SRow + i < CellNumber; ++i)
		{
			if (Board[SRow+i][SCol] == 1)
				++vNumber;
			else
				{
					HVMS[1][1].Row = SRow + i - 1;
					HVMS[1][1].Col = SCol;
					break;
				}
		}	
	}
	
	return vNumber;
} 

int Caro::CheckMainDiagonal(int PlayUser)
{
	int mNumber = 1;
	int i = 1;
	int k = 1;
	
	if (Board[SRow][SCol] == PlayUser)
	{
		//Up
		while ((SRow - i >= 0) && (SCol + i < CellNumber))
		{
			if (Board[SRow - i][SCol + i] == 1)
				{
					++mNumber;
					++i;
				}
			else
				{
					HVMS[2][0].Row = SRow - i + 1;
					HVMS[2][0].Col = SCol + i - 1;
					break;	
				}
				
		}
		
		while ((SRow + k < CellNumber) && (SCol - k >= 0))
		{
			if (Board[SRow + k][SCol - k] == 1)
				{
					++mNumber;
					++k;
				 }
			else
				{
					HVMS[2][1].Row = SRow + k - 1;
					HVMS[2][1].Col = SCol - k + 1;
					break; 
				}
		}
	}
			
	return mNumber;
}

int Caro::CheckSubDiagonal(int PlayUser)
{
	int sNumber = 1;
	int i = 1;
	int k = 1;
	
	if (Board[SRow][SCol] == PlayUser)
	{
		//Up
		while ((SRow - i >= 0) && (SCol - i >= 0))
		{
			if (Board[SRow-i][SCol-i] == 1)
				{
					++sNumber;
					++i;
				}
			else
				{
					HVMS[3][0].Row = SRow - i + 1;
					HVMS[3][0].Col = SCol - i + 1;
 					break;	
				}
				
		}
		
		//Down
		while ((SRow + k < CellNumber) && (SCol + k < CellNumber))
		{
			if (Board[SRow+k][SCol+k] == 1)
				{
					++sNumber;
					++k;
				}
			else
				{
					HVMS[3][1].Row = SRow + k - 1;
					HVMS[3][1].Col = SCol + k - 1;
					break;
				}
		}		
	}
	
	return sNumber; 
}

void Caro::CheckPvC()
{

}

int Caro::ComparePvC(int a, int b, int c, int d, int &Think)
{
	int LMax, RMax, Max;
	int SubThink, MainThink;
	
	if (a > b)
		{
			SubThink = 1;
			LMax = a;
		}
	else
		{
			LMax = b;
			SubThink = 2;	
		}
	
	if (c > d)
		{
			MainThink = 3;
			RMax = c;
		}
	else
		{
			MainThink = 4;
			RMax = d;	
		}
		
	if (RMax > LMax)
		{
			Think = MainThink;
			Max = RMax;
		}
	else
		{
			Max = LMax; 
			Think = SubThink;
		}
	
	return Max;	
}

void Caro::SwitchThinking()
{
	int Max;
	Max = ComparePvC(CheckHorizontally(1),CheckVertically(1),CheckMainDiagonal(1),CheckSubDiagonal(1),ThinkPlayer);
	
	switch (Max)
		{
			case 1:
				AttackRandom(FirstRow,FirstCol);
				break;	
			case 2:
				 // Attack
				AttackNextMove(FirstRow,FirstCol);
				break;
			case 3:
				Defense(ThinkPlayer);
				break;
			case 4:
				//Defense Prior
				Defense(ThinkPlayer);
				break;
		}
}

void Caro::AttackRandom(int &FirstRow, int &FirstCol)
{
	bool RandomMove = true;
	int Rnd;
	while (RandomMove)
	{
		Rnd = rand() % 8 + 1;
		switch (Rnd)
			{
				case 1:
					if ((Board[SRow][SCol+1] == 0) && (SCol + 1 < CellNumber))
						{
							RandomMove = false;
							SCol = SCol + 1;
							FirstRow = SRow;
							FirstCol = SCol;
						}
					break;
				case 2:
					if ((Board[SRow][SCol - 1] == 0) && (SCol - 1 >= 0))
						{
							RandomMove = false;
							SCol = SCol - 1;
							FirstRow = SRow;
							FirstCol = SCol;
						}
					break;
				case 3:
					if ((Board[SRow + 1][SCol] == 0) && (SRow + 1 < CellNumber))
						{
							RandomMove = false;
							SRow = SRow + 1;
							FirstRow = SRow;
							FirstCol = SCol;
						} 
					break;
				case 4:
					if ((Board[SRow - 1][SCol] == 0) && (SRow - 1 >= 0))
						{
							RandomMove = false;
							SRow = SRow - 1;
							FirstRow = SRow;
							FirstCol = SCol;
						}
					break;
				case 5:
					if ((Board[SRow + 1][SCol + 1] == 0) && (SRow + 1 < CellNumber) && (SCol + 1 < CellNumber))
						{
							RandomMove = false;
							SRow = SRow + 1;
							SCol = SCol + 1;
							FirstRow = SRow;
							FirstCol = SCol;
						}
					break;
				case 6:
					if ((Board[SRow - 1][SCol - 1] == 0) && (SRow - 1 >= 0) && (SCol - 1 >= 0))
						{
							RandomMove = false;
							SRow = SRow - 1;
							SCol = SCol - 1;
							FirstRow = SRow;
							FirstCol = SCol;
						}
					break;
				case 7: 
					if ((Board[SRow - 1][SCol + 1] == 0) && (SRow - 1 >= 0) && (SCol + 1 < CellNumber))
						{
							RandomMove = false;
							SRow = SRow - 1;
							SCol = SCol + 1;
							FirstRow = SRow;
							FirstCol = SCol;
						}
					break;
				case 8:
					if ((Board[SRow + 1][SCol - 1] == 0) && (SRow + 1 < CellNumber) && (SCol - 1 >= 0))
						{
							RandomMove = false;
							SRow = SRow + 1;
							SCol = SCol - 1;
							FirstRow = SRow;
							FirstCol = SCol;
						}
					break;
					
			}
	}
} 

void Caro::AttackNextMove(int FirstRow, int FirstCol)
{
	bool NextMove = true;
	int Rnd;
	while (NextMove)
	{
		Rnd = rand() % 8 + 1;
		switch (Rnd)
			{
				case 1:
					if ((Board[FirstRow][FirstCol+1] == 0) && (FirstCol + 1 < CellNumber))
						{
							NextMove = false;
							SRow = FirstRow;
							SCol = FirstCol + 1;
						}
					break;
				case 2:
					if ((Board[FirstRow][FirstCol - 1] == 0) && (FirstCol - 1 >= 0))
						{
							NextMove = false;
							SRow = FirstRow;
							SCol = FirstCol - 1;
						}
					break;
				case 3:
					if ((Board[FirstRow + 1][FirstCol] == 0) && (FirstRow + 1 < CellNumber))
						{
							NextMove = false;
							SRow = FirstRow + 1;
							SCol = FirstCol;
						} 
					break;
				case 4:
					if ((Board[FirstRow - 1][FirstCol] == 0) && (FirstRow - 1 >= 0))
						{
							NextMove = false;
							SRow = FirstRow - 1;
							SCol = FirstCol;
						}
					break;
				case 5:
					if ((Board[FirstRow + 1][FirstCol + 1] == 0) && (FirstRow + 1 < CellNumber) && (FirstCol + 1 < CellNumber))
						{
							NextMove = false;
							SRow = FirstRow + 1;
							SCol = FirstCol + 1;		
						}
					break;
				case 6:
					if ((Board[FirstRow - 1][FirstCol - 1] == 0) && (FirstRow - 1 >= 0) && (FirstCol - 1 >= 0))
						{
							NextMove = false;
							SRow = FirstRow - 1;
							SCol = FirstCol - 1;
						}
					break;
				case 7: 
					if ((Board[FirstRow - 1][FirstCol + 1] == 0) && (FirstRow - 1 >= 0) && (FirstCol + 1 < CellNumber))
						{
							NextMove = false;
							SRow = FirstRow - 1;
							SCol = FirstCol + 1;							
						}
					break;
				case 8:
					if ((Board[FirstRow + 1][FirstCol - 1] == 0) && (FirstRow + 1 < CellNumber) && (FirstCol - 1 >= 0))
						{
							NextMove = false;
							SRow = FirstRow + 1;
							SCol = FirstCol - 1;
						}
					break;
					
			}
	}
}

void Caro::Defense(int ThinkPlayer)
{
	switch (ThinkPlayer)
	{
		case 1:
			if ((Board[SRow][HVMS[0][0].Col + 1] == 0) && (HVMS[0][0].Col + 1 < CellNumber))
				{
					SCol = HVMS[0][0].Col + 1;
				}
			else
				if ((Board[SRow][HVMS[0][1].Col - 1] == 0) && (HVMS[0][1].Col - 1 >= 0))
					{
						SCol = HVMS[0][1].Col - 1;
					}
					
 			break;
		case 2:
			if ((Board[HVMS[1][0].Row - 1][SCol] == 0) && (HVMS[1][0].Row - 1 >= 0))
				{
					SRow = HVMS[1][0].Row - 1;
				}
			else
				if ((Board[HVMS[1][1].Row + 1][SCol] == 0) && (HVMS[1][1].Row + 1 < CellNumber))
					{
						SRow =HVMS[1][1].Row + 1;
					}
			break;
		case 3:
			if ((Board[HVMS[2][0].Row - 1][HVMS[2][0].Col + 1] == 0) && (HVMS[2][0].Row - 1 >= 0) && (HVMS[2][0].Col + 1 < CellNumber))
				{
					SRow = HVMS[2][0].Row - 1;
					SCol = HVMS[2][0].Col + 1;
				}
			else
				if ((Board[HVMS[2][1].Row + 1][HVMS[2][1].Col - 1] == 0) && (HVMS[2][1].Row + 1 < CellNumber) && (HVMS[2][1].Col - 1 >= 0))
					{
						SRow = HVMS[2][1].Row + 1;
						SCol = HVMS[2][1].Col - 1;
					}
			break;
		case 4:
			if ((Board[HVMS[3][0].Row - 1][HVMS[3][0].Col - 1] == 0) && (HVMS[3][0].Row - 1 >= 0) && (HVMS[3][0].Col - 1 >= 0))
				{
					SRow = HVMS[3][0].Row - 1;
					SCol = HVMS[3][0].Col - 1;
				}
			else
				if ((Board[HVMS[3][1].Row + 1][HVMS[3][1].Col + 1] == 0) && (HVMS[3][1].Row + 1 < CellNumber) && (HVMS[3][1].Col + 1 < CellNumber))
					{
						SRow = HVMS[3][1].Row + 1;
						SCol = HVMS[3][1].Col + 1;
					}
		break;
	}
}

void Caro::EasyPvC()
{
	SwitchThinking();
}

#endif

