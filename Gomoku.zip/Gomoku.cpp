
#include <cstdlib>
#include <conio.h>
#include <iostream>
#include <cmath>
#include <windows.h>
#include <string>
#include <cstring>
#include <Caro.h>
#include <Key.h>
#include <Menu.h>
#include <Splash.h>

int main()
{
	ResizeConsole(1920,1080);
	Splash();
	Menu Go;
	Go.Start();
	return 0;
}
