#ifndef _Key_H_
#define _Key_H_


#include <cstdlib>
#include <conio.h>
#include <iostream>
#include <cmath>
#include <windows.h>
#include <cstring>
#include <Caro.h>

#define ButtonWidth 8
#define ButtonHeight 3
#define SBWidth 30
#define SBHeight 3

using namespace std;

	char DownRight = putchar(217);
	char UpRight = putchar(191);
	char DownLeft = putchar(192);
	char UpLeft = putchar(218);
	char Bar = putchar (196);
	char Javelin = putchar(179);

void clrscr()
{
	system("cls");
}

void SetColor(WORD color = 7) 
{
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), color);
}

void gotoXY(int x, int y) 
{ 
    COORD pos = {x, y};
    HANDLE output = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleCursorPosition(output, pos);
}

void ResizeConsole(int width, int height)
{
	HWND console = GetConsoleWindow();
	RECT r;
	GetWindowRect(console, &r);
	MoveWindow(console,r.left,r.top,width,height,TRUE);
}

void DrawBox()
{
	int BoxHeight = 9;
	int BoxWidth = SBWidth;
	
	SetColor(7);
	char Box[BoxHeight][BoxWidth] = 
	{
		{UpLeft, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, UpRight},
		{Javelin, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', Javelin},
		{Javelin, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', Javelin},
		{Javelin, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', Javelin},
		{Javelin, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', Javelin},
		{Javelin, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', Javelin},
		{Javelin, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', Javelin},
		{Javelin, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', Javelin},
		{DownLeft, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, DownRight},
	};
	
	for ( int i = 0; i < BoxHeight; ++i )
	{
		gotoXY(170-BoxWidth-11, 40 - BoxHeight + i);
		for ( int j = 0; j < BoxWidth; ++j )
			cout << Box[i][j];
	}
}

void DrawButton (int x, int y)
{
	char Button[ButtonHeight][ButtonWidth] = 
	{
		{UpLeft, Bar, Bar, Bar, Bar, Bar, Bar, UpRight},
		{Javelin, ' ', ' ', ' ', ' ', ' ', ' ', Javelin},
		{DownLeft, Bar, Bar, Bar, Bar, Bar, Bar, DownRight},
	};
	
	for ( int i = 0; i < ButtonHeight; ++i )
	{
		gotoXY(x,y+i);
		for ( int j = 0; j < ButtonWidth; ++j )
			cout << Button[i][j];
	}
}

void DrawSpacebar(int Color = 7)
{
	SetColor(Color);
	char Spacebar[SBHeight][SBWidth] = 
	{
		{UpLeft, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, UpRight},
		{Javelin, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', Javelin},
		{DownLeft, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, DownRight},
	};
	
	for ( int i = 0; i < SBHeight; ++i )
	{
		gotoXY(170-SBWidth-11, 40 - SBHeight + i);
		for ( int j = 0; j < SBWidth; ++j )
			cout << Spacebar[i][j];
	} 
	
	gotoXY (170 - SBWidth + 1 ,40 - SBHeight + 1);
	cout << "SPACEBAR";
}

void UpButton(int Color = 7)
{ 
	SetColor(Color);
	DrawButton(170 - ButtonWidth - 22, 40 - SBHeight - ButtonHeight - 3);
	gotoXY(170 - 29 + 2, 40 - 14 + 6);
	cout << "UP";
}

void DownButton(int Color = 7)
{
	SetColor(Color);
	DrawButton(170 - ButtonWidth - 22, 40 - SBHeight - ButtonHeight);
	gotoXY(170 - 29 + 1, 40 - 14 + 9);
	cout << "DOWN";	
}

void LeftButton(int Color = 7)
{
	SetColor(Color);
	DrawButton(170 - ButtonWidth - 33, 40 - SBHeight - ButtonHeight);
	gotoXY(170 - 29 -10, 40 - 14 + 9);
	cout << "LEFT";	
}

void RightButton(int Color = 7)
{
	SetColor(Color);
	DrawButton(170 - ButtonWidth - 10 - 1, 40 - SBHeight - ButtonHeight);
	gotoXY(170 - 29 + 13 - 1, 40 - 14 + 9);
	cout << "RIGHT";	
}

void EnterButton(int Color = 7)
{
	int EnterHeight = 9;
	int EnterWidth = 9;
	
	SetColor(Color);
	char Enter [EnterHeight][EnterWidth] = 
	{
		{UpLeft, Bar, Bar, Bar, Bar, Bar, Bar, Bar, UpRight},
		{Javelin, ' ', ' ', ' ', ' ', ' ', ' ', ' ', Javelin},
		{Javelin, ' ', ' ', ' ', ' ', ' ', ' ', ' ', Javelin},
		{Javelin, ' ', ' ', ' ', ' ', ' ', ' ', ' ', Javelin},
		{Javelin, ' ', ' ', ' ', ' ', ' ', ' ', ' ', Javelin},
		{Javelin, ' ', ' ', ' ', ' ', ' ', ' ', ' ', Javelin},
		{Javelin, ' ', ' ', ' ', ' ', ' ', ' ', ' ', Javelin},
		{Javelin, ' ', ' ', ' ', ' ', ' ', ' ', ' ', Javelin},
		{DownLeft, Bar, Bar, Bar, Bar, Bar, Bar, Bar, DownRight},
	};
	
	for ( int i = 0; i < EnterHeight; ++i )
		{
			gotoXY(170-EnterWidth-1, 40 - EnterHeight + i);
			for ( int j = 0; j < EnterWidth; ++j )
					cout << Enter[i][j];
		}	
	
	gotoXY(170-EnterWidth+1, 40 - EnterHeight+3);
	cout << "ENTER";		
}

void Palette()
{
	for ( int i = 1; i <= 15; ++i )
		{
			SetColor(i);
			gotoXY(10,15 + i);
			if ( i > 9 )
				cout << i << "     ";
			else
				cout << i << "      ";
			for ( int j = 0; j < 20; ++j )
			{
				putchar(223);
			}
		}
}

void DrawBox2()
{
	int Box2Height = 24;
	int Box2Width = 44;
	
	SetColor(1);
	char Box2[Box2Height][Box2Width] = 
	{
		{UpLeft, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, UpRight},
		{Javelin, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', Javelin},
		{Javelin, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', Javelin},
		{Javelin, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', Javelin},
		{Javelin, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', Javelin},
		{Javelin, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', Javelin},
		{Javelin, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', Javelin},
		{Javelin, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', Javelin},
		{Javelin, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', Javelin},
		{Javelin, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', Javelin},
		{Javelin, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', Javelin},
		{Javelin, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', Javelin},
		{Javelin, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', Javelin},
		{Javelin, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', Javelin},
		{Javelin, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', Javelin},
		{Javelin, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', Javelin},
		{Javelin, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', Javelin},
		{Javelin, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', Javelin},
		{Javelin, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', Javelin},
		{Javelin, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', Javelin},
		{Javelin, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', Javelin},
		{Javelin, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', Javelin},
		{Javelin, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', Javelin},
		{DownLeft, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, DownRight},
	};
	
	for ( int i = 0; i < Box2Height; ++i )
	{
		gotoXY(127, 7 + i );
		for ( int j = 0; j < Box2Width; ++j )
			cout << Box2[i][j];
	}
	
	
}

void Instructions()
{
	char Line[22] = {Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar, Bar};
	char Note = putchar(254);
	gotoXY(140,8);
	cout << " INSTRUCTIONS: ";
	for ( int i = 0; i < 23; ++i )
	{
		gotoXY(137+i, 9);
		cout << Line[i];
	}
	SetColor(6);
	gotoXY(132,10);
	cout << Note << " UP key --> MOVE UP";
	gotoXY(132,12);
	cout << Note <<  " DOWN key --> MOVE DOWN";
	gotoXY(132,14);
	cout << Note << " LEFT key --> MOVE LEFT";
	gotoXY(132,16);
	cout << Note << " RIGHT key --> MOVE RIGHT";
	gotoXY(132,18);
	cout << Note << " ENTER --> CONFIRM CHECKER LOCATION";
	gotoXY(132,20);
	cout << Note << " SPACEBAR --> UNDO" ;
	gotoXY(132,22);
	cout << Note << " Press S --> SAVE GAME";
}

void Checker()
{
	gotoXY(132,15);
	cout << "1 --> "; putchar(33);
	gotoXY(132,17);
	cout << "2 --> "; putchar(36);
	gotoXY(132,19);
	cout << "3 --> "; putchar(38);
	gotoXY(132,21);
 	cout << "4 --> "; putchar(64);
 	gotoXY(132,23);
 	cout << "5 --> "; putchar(156);
 	gotoXY(132,25);
 	cout << "6 --> "; putchar(35);
 	gotoXY(132,27);
 	cout << "7 --> "; putchar(225);
 	gotoXY(132,29);
 	cout << "8 --> "; putchar(230);
}

void Console()
{
	DrawBox();
	DrawSpacebar(); 
	UpButton();
	DownButton();
	LeftButton();
	RightButton();
	EnterButton(); 
	DrawBox2();
	Instructions();
}




#endif
