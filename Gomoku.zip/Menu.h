#ifndef _Menu_H_
#define _Menu_H_

#include <iostream>
#include <windows.h>
#include <conio.h>
#include <stdio.h>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <string.h>
#include <fstream>
#include <Caro.h>
#include <Key.h>

#define consoleWidth 140
#define PixelHeight 8
#define Space 3
#define PlayWidth 23
#define OptionsWidth 37
#define AboutWidth 29
#define PvPWidth 17
#define YesWidth 17
#define NoWidth 11
#define ModeWidth 31
#define NewGameWidth 80
#define ContinueWidth 49

using namespace std;



class Menu
{
	public: 
		int x;
		int y;
		int Width;
		int Height;
		int Play = 0;
		int Cell = 20;
		int Node = 5;
		int LoadFile = 0;
		int PvC = 0;
		int cOptions;
		char* MFileName;
		char* tail = ".txt";
		string mFileName;
	
		User P1;
		User P2;
	
	private:
		void DrawPlay(int color);
		void DrawContinue(int color);
		void DrawOptions(int color);
		void DrawAbout(int color);
		void DrawPvP(int color);
		void DrawPvC(int color);
		void DrawYes(int color);
		void DrawNo(int color);
		void DrawPvPPvC();
		void DrawNewGameBoard();
		void DrawGameOver(int color);
		void Options();
		void DrawNewGame();
		void DrawMode(); 
		
		
	public: 
		void DrawMenuBoard();
		void DrawWinner();
		void PvP();
		void PlayerInfo();
		int CheckInput(int Max, int Min, string S, int X, int Y);
		char PlayerChecker(int Nu);
		void CaroPvC();
		void Start();
		char* Convert(string mFileName);
		
};

void Menu::DrawPlay(int color = 7)
{
	SetColor(color);
	
	int PlayCoordX = 75;
	int PlayCoordY = 8;
	
	while(1)
	{
		for ( int j = 1; j <= PixelHeight; ++j )
		{
			gotoXY(PlayCoordX,PlayCoordY);
			switch (j)
			{
				case 1:
				{
					for ( int i = 1; i <= PlayWidth; ++i )
						if ((i==1)||(i==2)||(i==3)||(i==4)||(i==7)||(i==15)||(i==19)||(i==23))
							putchar(178);
						else
							cout << " ";
					break;	
				}
	 			case 2:
	 			{
	 				for ( int i = 1; i <= PlayWidth; ++i )
	 					if ((i==1)||(i==5)||(i==7)||(i==14)||(i==16)||(i==19)||(i==23))
	 						putchar(178);
	 					else
	 						cout << " ";
					break;
				}
				case 3:
				{
					for ( int i = 1; i <= PlayWidth; ++i )
						if ((i==1)||(i==5)||(i==7)||(i==13)||(i==17)||(i==19)||(i==23))
							putchar(178);
						else
							cout << " ";
					break;
				}	
				case 4:
				{
					for ( int i = 1; i <= PlayWidth; ++i )
						if ((i==1)||(i==2)||(i==3)||(i==4)||(i==7)||(i==13)||(i==17)||(i==20)||(i==22))
							putchar(178);
						else
							cout << " ";
					break;
				}
				case 5:
				{
					for ( int i = 1; i <= PlayWidth; ++i )
						if ((i==1)||(i==7)||(i==13)||(i==14)||(i==14)||(i==15)||(i==16)||(i==17)||(i==21))
							putchar(178);
						else
							cout << " ";
					break;
				}
				case 6:
				{
					for ( int i = 1; i <= PlayWidth; ++i )
						if ((i==1)||(i==7)||(i==13)||(i==17)||(i==21))
							putchar(178);
						else
							cout << " ";
					break;
				}
				case 7:
				{
					for ( int i = 1; i <= PlayWidth; ++i )
						if ((i==1)||(i==7)||(i==13)||(i==17)||(i==21))
							putchar(178);
						else
							cout << " ";					
					break;
				}
				case 8:
				{
					for ( int i = 1; i <= PlayWidth; ++i )
						if ((i==1)||(i==7)||(i==8)||(i==8)||(i==9)||(i==10)||(i==11)||(i==13)||(i==17)||(i==21))
							putchar(178);
						else
							cout << " ";
					break;
				}
			}
			++PlayCoordY;
		};
		if ( PlayCoordY == 5 + Space + PixelHeight  ) break;
	}
	SetColor();
}
	
void Menu::DrawOptions(int color = 7)
{
	SetColor(color);
	
	int OptionsCoordX = 70;
	int OptionsCoordY = 19;
	
	gotoXY(22,12);
		while(1)
	{
		for ( int j = 1; j <= PixelHeight; ++j )
		{
			gotoXY(OptionsCoordX,OptionsCoordY);
			switch (j)
			{
				case 1:
				{
					for ( int i = 1; i <= OptionsWidth; ++i )
						if ((i==2)||(i==3)||(i==4)||(i==7)||(i==8)||(i==9)||(i==10)||(i==13)||(i==14)||(i==15)||(i==16)||(i==17)||(i==19)||(i==22)|(i==23)||(i==24)||(i==27)||(i==31)||(i==34)||(i==35)||(i==36))
							putchar(178);
						else
							cout << " ";
					break;	
				}
	 			case 2:
	 			{
	 				for ( int i = 1; i <= OptionsWidth; ++i )
	 					if ((i==1)||(i==5)||(i==7)||(i==11)||(i==15)||(i==19)||(i==21)||(i==25)||(i==27)||(i==28)||(i==31)||(i==33)||(i==37))
	 						putchar(178);
	 					else
	 						cout << " ";
					break;
				}
				case 3:
				{
					for ( int i = 1; i <= OptionsWidth; ++i )
						if ((i==1)||(i==5)||(i==7)||(i==11)||(i==15)||(i==19)||(i==21)||(i==25)||(i==27)||(i==28)||(i==31)||(i==33)||(i==37))
							putchar(178);
						else
							cout << " ";
					break;
				}	
				case 4:
				{
					for ( int i = 1; i <= OptionsWidth; ++i )
						if ((i==1)||(i==5)||(i==7)||(i==8)||(i==9)||(i==10)||(i==15)||(i==19)||(i==21)||(i==25)||(i==27)||(i==29)||(i==31)||(i==34)||(i==35))
							putchar(178);
						else
							cout << " ";
					break;
				}
				case 5:
				{
					for ( int i = 1; i <= OptionsWidth; ++i )
						if ((i==1)||(i==5)||(i==7)||(i==15)||(i==19)||(i==21)||(i==25)||(i==27)||(i==29)||(i==31)||(i==36))
							putchar(178);
						else
							cout << " ";
					break;
				}
				case 6:
				{
					for ( int i = 1; i <= OptionsWidth; ++i )
						if ((i==1)||(i==5)||(i==7)||(i==15)||(i==19)||(i==21)||(i==25)||(i==27)||(i==30)||(i==31)||(i==33)||(i==37))
							putchar(178);
						else
							cout << " ";
					break;
				}
				case 7:
				{
					for ( int i = 1; i <= OptionsWidth; ++i )
						if ((i==1)||(i==5)||(i==7)||(i==15)||(i==19)||(i==21)||(i==25)||(i==27)||(i==30)||(i==31)||(i==33)||(i==37))
							putchar(178);
						else
							cout << " ";					
					break;
				}
				case 8:
				{
					for ( int i = 1; i <= OptionsWidth; ++i )
						if ((i==2)||(i==3)||(i==4)||(i==7)||(i==15)||(i==19)||(i==22)||(i==23)||(i==24)||(i==27)||(i==31)||(i==34)||(i==35)||(i==36))
							putchar(178);
						else
							cout << " ";
					break;
				}
			}
			++OptionsCoordY;
		};
		if ( OptionsCoordY == 5 + Space + PixelHeight + Space + PixelHeight ) break;
	}
	SetColor();
}

void Menu::DrawAbout(int color = 7)
{
	SetColor(color);
	
	int AboutCoordX = 73;
	int AboutCoordY = 5 + Space + PixelHeight + Space + PixelHeight + Space;
	
		while(1)
	{
		for ( int j = 1; j <= PixelHeight; ++j )
		{
			gotoXY(AboutCoordX, AboutCoordY);
			switch (j)
			{
				case 1:
				{
					for ( int i = 1; i <= AboutWidth; ++i )
						if ((i==3)||(i==7)||(i==8)||(i==9)||(i==10)||(i==14)||(i==15)||(i==16)||(i==19)||(i==23)||(i==25)||(i==26)||(i==27)||(i==28)||(i==29))
							putchar(178);
						else
							cout << " ";
					break;	
				}
	 			case 2:
	 			{
	 				for ( int i = 1; i <= AboutWidth; ++i )
	 					if ((i==2)||(i==4)||(i==7)||(i==11)||(i==13)||(i==17)||(i==19)||(i==23)||(i==27))
	 						putchar(178);
	 					else
	 						cout << " ";
					break;
				}
				case 3:
				{
					for ( int i = 1; i <= AboutWidth; ++i )
						if ((i==1)||(i==5)||(i==7)||(i==11)||(i==13)||(i==17)||(i==19)||(i==23)||(i==27))
							putchar(178);
						else
							cout << " ";
					break;
				}	
				case 4:
				{
					for ( int i = 1; i <= AboutWidth; ++i )
						if ((i==1)||(i==5)||(i==7)||(i==8)||(i==9)||(i==10)||(i==13)||(i==17)||(i==19)||(i==23)||(i==27))
							putchar(178);
						else
							cout << " ";
					break;
				}
				case 5:
				{
					for ( int i = 1; i <= AboutWidth; ++i )
						if ((i==1)||(i==2)||(i==3)||(i==4)||(i==5)||(i==7)||(i==11)||(i==13)||(i==13)||(i==17)||(i==19)||(i==19)||(i==23)||(i==27))
							putchar(178);
						else
							cout << " ";
					break;
				}
				case 6:
				{
					for ( int i = 1; i <= AboutWidth; ++i )
						if ((i==1)||(i==5)||(i==7)||(i==11)||(i==13)||(i==17)||(i==19)||(i==23)||(i==27))
							putchar(178);
						else
							cout << " ";
					break;
				}
				case 7:
				{
					for ( int i = 1; i <= AboutWidth; ++i )
						if ((i==1)||(i==5)||(i==7)||(i==11)||(i==13)||(i==17)||(i==19)||(i==23)||(i==27))
							putchar(178);
						else
							cout << " ";					
					break;
				}
				case 8:
				{
					for ( int i = 1; i <= AboutWidth; ++i )
						if ((i==1)||(i==5)||(i==7)||(i==8)||(i==9)||(i==10)||(i==14)||(i==15)||(i==15)||(i==16)||(i==20)||(i==21)||(i==22||(i==27)))
							putchar(178);
						else
							cout << " ";
					break;
				}
			}
			++AboutCoordY;
		};
		if (  AboutCoordY == 5 + Space + PixelHeight + Space + PixelHeight + Space + PixelHeight ) break;
	}
	SetColor();
}

void Menu::DrawPvP(int color = 7)
{
	SetColor(color);
	
	int CoordPvP = 15;
	int PvCoord = 82;
	char p = putchar(178);
					
	char PvP[PixelHeight][PvPWidth] =
	{
		{p, p, p, p, ' ', ' ', p, ' ', ' ', ' ', p, ' ', p, p, p, p, ' ' },
		{p, ' ', ' ', ' ', p, ' ',p, ' ', ' ', ' ', p, ' ', p, ' ', ' ', ' ',p},
		{p, ' ', ' ', ' ', p, ' ', p, ' ', ' ', ' ', p, ' ', p, ' ', ' ', ' ', p},
		{p, p, p, p, ' ', ' ', p, ' ', ' ', ' ', p, ' ', p, p, p, p, ' '},
		{p, ' ', ' ', ' ', ' ', ' ', p, ' ', ' ', ' ', p, ' ', p, ' ', ' ', ' ', ' '},
		{p, ' ', ' ', ' ', ' ', ' ', p, ' ', ' ', ' ', p, ' ', p, ' ', ' ', ' ', ' '},
		{p, ' ', ' ', ' ', ' ', ' ', ' ', p, ' ', p, ' ', ' ', p, ' ', ' ', ' ', ' '},
		{p, ' ', ' ', ' ', ' ', ' ', ' ', ' ', p, ' ', ' ', ' ', p, ' ', ' ', ' ', ' '},
	};

	
	for ( int i = 0; i <= PixelHeight - 1; ++i )
		{
			gotoXY(PvCoord,CoordPvP);
			for ( int j = 0; j <= PvPWidth - 1; ++j )
				cout << PvP[i][j];
			++CoordPvP;
		}
	gotoXY(0,0);
	SetColor();
}

void Menu::DrawPvC(int color = 7)
{
	SetColor(color);
	
	int CoordPvC = 26;
	int PvCoord = 82;;
	char p = putchar(178);
					
	char PvC[PixelHeight][PvPWidth] =
	{
		{p, p, p, p, ' ', ' ', p, ' ', ' ', ' ', p, ' ', ' ', p, p, p, ' ' },
		{p, ' ', ' ', ' ', p, ' ',p, ' ', ' ', ' ', p, ' ', p, ' ', ' ', ' ',p},
		{p, ' ', ' ', ' ', p, ' ', p, ' ', ' ', ' ', p, ' ', p, ' ', ' ', ' ', ' '},
		{p, p, p, p, ' ', ' ', p, ' ', ' ', ' ', p, ' ', p, ' ', ' ', ' ', ' '},
		{p, ' ', ' ', ' ', ' ', ' ', p, ' ', ' ', ' ', p, ' ', p, ' ', ' ', ' ', ' '},
		{p, ' ', ' ', ' ', ' ', ' ', p, ' ', ' ', ' ', p, ' ', p, ' ', ' ', ' ', ' '},
		{p, ' ', ' ', ' ', ' ', ' ', ' ', p, ' ', p, ' ', ' ', p, ' ', ' ', ' ', p},
		{p, ' ', ' ', ' ', ' ', ' ', ' ', ' ', p, ' ', ' ', ' ', ' ', p, p, p, ' '},
	};

	for ( int i = 0; i <= PixelHeight - 1; ++i )
		{
			gotoXY (PvCoord,CoordPvC);
			for ( int j = 0; j <= PvPWidth - 1; ++j )
				cout << PvC[i][j];
			++CoordPvC;
		}
	gotoXY(0,0);
	SetColor();
}

void Menu::DrawMode()
{
	SetColor(6);
	
	int CoordMode = 0;
	char p = putchar(178);
	
	char Mode[PixelHeight][ModeWidth] = 
	{
		{p, p, p, ' ', ' ', ' ', p, p, p, ' ', ' ', p, p, p, p, ' ', ' ', p, p, p, p, p, ' ', ' ', ' ', p, p, p, p, p, p},
		{ ' ', p, ' ', ' ', ' ', ' ', ' ', p, ' ', ' ', p, ' ', ' ', ' ', ' ', p, ' ', ' ', p, ' ', ' ', ' ', p, ' ', ' ', ' ', p, ' ', ' ', ' ', p},
		{ ' ', p, p, ' ', ' ', ' ', p, p, ' ', ' ', p, ' ', ' ', ' ', ' ', p, ' ', ' ', p, ' ', ' ', ' ', ' ', p, ' ', ' ', p, ' ', ' ', ' ', ' ',},
		{ ' ', p,  ' ', p, ' ', p, ' ', p, ' ', ' ', p, ' ', ' ', ' ', ' ', p,  ' ', ' ', p, ' ', ' ', ' ', ' ', p, ' ', ' ', p, p, p, p, ' ',},
		{ ' ', p, ' ', ' ', p,  ' ', ' ', p, ' ', ' ', p, ' ', ' ', ' ', ' ', p, ' ', ' ', p, ' ', ' ', ' ', ' ', p, ' ', ' ', p, ' ', ' ', ' ', ' '},
		{' ', p, ' ', ' ', p, ' ', ' ', p, ' ', ' ' , p, ' ', ' ', ' ', ' ', p, ' ', ' ', p, ' ', ' ', ' ', ' ', p, ' ', ' ', p, ' ', ' ', ' ', ' '},
		{' ', p, ' ', ' ', ' ', ' ', ' ', p, ' ', ' ', p, ' ', ' ', ' ', ' ', p, ' ', ' ', p, ' ', ' ', ' ', p, ' ', ' ', ' ', p, ' ', ' ', ' ', p},
		{p , p, p, ' ', ' ', ' ', p, p, p, ' ', ' ', p, p, p, p, ' ', ' ', p, p, p, p, p, ' ', ' ', ' ', p, p, p, p, p, p},
	};
	
	for ( int i = 0; i <= PixelHeight - 1; ++i )
		{
			gotoXY (75,CoordMode);
			for ( int j = 0; j <= ModeWidth - 1; ++j )
				cout << Mode[i][j];
			++CoordMode;
		}
	gotoXY(0,0);
}

void Menu::DrawNewGame()
{
	SetColor(6);
	
	int CoordNewGame = 0;
	char p = putchar(178);
	
	char NewGame[PixelHeight][NewGameWidth] = 
	{
		{p, p, p, ' ', ' ', p, p, p, ' ', p, p, p, p, p, p, ' ', p, p, p, ' ', ' ', ' ', ' ', ' ', p, p, p, ' ', ' ', ' ', ' ', p, p, p, p, ' ', ' ', ' ', ' ', ' ', p, p, ' ', ' ', ' ', ' ', p, p ,p, ' ', ' ', ' ', p, p, p, ' ', p, p, p, p, p, p, ' ', ' ', p, p, ' ' },
		{' ', p, ' ', ' ', ' ', ' ', p, ' ', ' ', ' ', p, ' ', ' ', ' ', p, ' ', ' ', p, ' ', ' ', ' ', ' ', ' ', ' ', ' ', p, ' ', ' ', ' ', ' ', p, ' ', ' ', ' ', ' ', p, ' ', ' ', ' ', p, ' ', ' ', p, ' ', ' ', ' ', ' ', p, ' ', ' ', ' ', ' ', ' ', p, ' ', ' ', ' ', p, ' ', ' ', ' ', p, ' ' , p, ' ', ' ', p},
		{' ', p, p, ' ', ' ', ' ', p, ' ', ' ', ' ', p, ' ', ' ', ' ', ' ', ' ', ' ', p, ' ', ' ', ' ', ' ', ' ', ' ', ' ', p, ' ', ' ', ' ', ' ', p, ' ', ' ', ' ', ' ', ' ', ' ', ' ', p, ' ', ' ', ' ', ' ', p, ' ', ' ', ' ', p, p, ' ', ' ', ' ', p, p, ' ', ' ', ' ', p, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', p},
		{' ', p, ' ', p, ' ', ' ', p, ' ', ' ', ' ', p, p, p, p, ' ', ' ', ' ', p, ' ', ' ', ' ', p, ' ', ' ', ' ', p, ' ', ' ', ' ', ' ', p, ' ', ' ', ' ', ' ', ' ', ' ', ' ', p, ' ', ' ', ' ', ' ', p, ' ', ' ', ' ', p, ' ', p, ' ', p, ' ', p, ' ', ' ', ' ', p, p, p, p, ' ', ' ', ' ', ' ', p, ' '},
		{' ', p, ' ', ' ', p, ' ', p, ' ', ' ', ' ', p, ' ', ' ', ' ', ' ', ' ', ' ', ' ', p, ' ', ' ', p, ' ', ' ', p, ' ', ' ', ' ', ' ', ' ', p, ' ', ' ', ' ', p, p, ' ', ' ', p, p, p, p, p, p, ' ', ' ', ' ', p, ' ', ' ', p, ' ', ' ', p, ' ', ' ', ' ', p, ' ', ' ', ' ', ' ', ' ', ' ', p, ' ', ' '},
		{' ', p, ' ', ' ', ' ', p, p, ' ', ' ', ' ' , p, ' ', ' ', ' ', ' ', ' ', ' ', ' ', p, ' ', p, ' ', p, ' ' , p, ' ', ' ', ' ', ' ', ' ', p, ' ', ' ', ' ', ' ', p, ' ', ' ', p, ' ', ' ', ' ', ' ', p, ' ', ' ', ' ', p, ' ', ' ', p, ' ', ' ', p, ' ', ' ', ' ', p, ' ', ' ', ' ', ' ', ' ', ' ', p, ' ', ' '},
		{' ', p, ' ', ' ', ' ', ' ', p, ' ', ' ', ' ', p, ' ', ' ', ' ', p, ' ', ' ', ' ', p, ' ', p, ' ', p, ' ', p, ' ', ' ', ' ', ' ', ' ', p, ' ', ' ', ' ', ' ', p, ' ', ' ', p, ' ', ' ', ' ', ' ', p, ' ', ' ', ' ', p, ' ', ' ', ' ', ' ', ' ', p, ' ', ' ', ' ', p, ' ', ' ', ' ', p, ' ', ' ', ' ', ' ', ' '},
		{p ,p, p, ' ', ' ', p, p, p, ' ', p, p, p, p, p, p, ' ', ' ', ' ', ' ', p, ' ', ' ', ' ', p, ' ', ' ', ' ', ' ', ' ', ' ', ' ', p, p, p, p, ' ', ' ', p, p, p, ' ', ' ', p, p, p, ' ', p, p, p, ' ', ' ', ' ', p, p, p, ' ', p, p, p, p, p, p, ' ', ' ', p, ' ', ' ' },
	};
	
	for ( int i = 0; i <= PixelHeight - 1; ++i )
		{
			gotoXY (58,CoordNewGame);
			for ( int j = 0; j <= NewGameWidth - 1; ++j )
				cout << NewGame[i][j];
			++CoordNewGame;
		}
	gotoXY(0,0);
}

void Menu::DrawContinue(int color = 9)
{
	SetColor(color);
	
	int ContinueCoordX = 64;
	int ContinueCoordY = 0;
	char p = putchar(178);
	
	char Continue[PixelHeight][ContinueWidth] = 
	{
		{' ',p , p, p, ' ', ' ', ' ', p, p, p, ' ', ' ', p, ' ', ' ', ' ', p, ' ', p, p, p, p, p, ' ', p, ' ', p, ' ', ' ', ' ', p, ' ', p, ' ', ' ', ' ', p, ' ', p, p, p, p, p, ' ', ' ', p, p, p, ' '},
		{p, ' ', ' ', ' ', p, ' ', p, ' ', ' ', ' ', p, ' ', p, p, ' ', ' ', p, ' ', ' ', ' ', p, ' ', ' ', ' ', p, ' ', p, p, ' ', ' ', p, ' ', p, ' ', ' ', ' ', p, ' ', p, ' ', ' ', ' ', ' ', ' ', p, ' ', ' ', ' ', p},
		{p, ' ', ' ', ' ', ' ', ' ', p, ' ', ' ', ' ', p, ' ', p, p, ' ', ' ', p, ' ', ' ', ' ', p, ' ', ' ', ' ', p, ' ', p, p, ' ', ' ', p, ' ', p, ' ', ' ', ' ', p, ' ', p, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', p},
		{p, ' ', ' ', ' ', ' ', ' ', p, ' ', ' ', ' ', p, ' ', p, ' ', p, ' ', p, ' ', ' ', ' ', p, ' ', ' ', ' ', p, ' ', p, ' ', p, ' ', p, ' ', p, ' ', ' ', ' ', p, ' ', p, p, p, p, ' ', ' ', ' ', ' ', ' ', p, ' '},
		{p, ' ', ' ', ' ', ' ', ' ', p, ' ', ' ', ' ', p, ' ', p, ' ', p, ' ', p, ' ', ' ', ' ', p, ' ', ' ', ' ', p, ' ', p, ' ', p, ' ', p, ' ', p, ' ', ' ', ' ', p, ' ', p, ' ', ' ', ' ', ' ', ' ', ' ', ' ', p, ' ', ' '},
		{p, ' ', ' ', ' ', ' ', ' ', p, ' ', ' ', ' ', p, ' ', p, ' ', ' ', p, p, ' ', ' ', ' ', p, ' ', ' ', ' ', p, ' ', p, ' ', ' ', p, p, ' ', p, ' ', ' ', ' ', p, ' ', p, ' ', ' ', ' ', ' ', ' ', ' ', ' ', p, ' ', ' '},
		{p, ' ', ' ', ' ', p, ' ', p, ' ', ' ', ' ', p, ' ', p, ' ', ' ', p, p, ' ', ' ', ' ', p, ' ', ' ', ' ', p, ' ', p, ' ', ' ', p, p, ' ', p, ' ', ' ', ' ', p, ' ', p, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '},
		{' ', p, p, p, ' ', ' ', ' ', p, p, p, ' ', ' ', p, ' ', ' ', ' ', p, ' ', ' ', ' ', p, ' ', ' ', ' ', p, ' ', p, ' ', ' ', ' ', p, ' ', ' ', p, p, p, ' ', ' ', p, p, p, p, p, ' ', ' ', ' ', p, ' ', ' '}, 
	};
	
	for ( int i = 0; i <= PixelHeight - 1; ++i )
		{
			gotoXY(ContinueCoordX,ContinueCoordY);
			for ( int j = 0; j <= ContinueWidth -1; ++j )
				cout << Continue[i][j];
			++ContinueCoordY;
		};
	gotoXY(0, 0);
} 

void Menu::DrawYes(int color = 7)
{
	int YesCoordX = 82;
	int YesCoordY = 15;
	char p = putchar(178);
	
	SetColor(color);
	char Continue[PixelHeight][YesWidth] = 
	{
		{p, ' ', ' ', ' ', p, ' ', p, p, p, p, p, ' ', ' ', p, p, p, ' '},
		{p, ' ', ' ', ' ', p, ' ', p, ' ', ' ', ' ', ' ', ' ', p, ' ', ' ', ' ', p},
		{p, ' ', ' ', ' ', p, ' ', p, ' ', ' ', ' ', ' ', ' ', p, ' ', ' ', ' ', p},
		{' ', p, ' ', p, ' ', ' ', p, p, p, p, ' ', ' ', ' ', p, p, ' ', ' '},
		{' ', ' ', p, ' ', ' ', ' ', p, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', p, ' '},
		{' ', ' ', p, ' ', ' ', ' ', p, ' ', ' ', ' ', ' ', ' ', p, ' ', ' ', ' ', p},
		{' ', ' ', p, ' ', ' ', ' ', p, ' ', ' ', ' ', ' ', ' ', p, ' ', ' ', ' ', p},
		{' ', ' ', p, ' ', ' ', ' ', p, p, p, p, p, ' ', ' ', p, p, p, ' '},
		
	};
	
	for ( int i = 0; i <= PixelHeight - 1; ++i )
		{
			gotoXY(YesCoordX, YesCoordY);
			for ( int j = 0; j <= YesWidth -1; ++j )
				cout << Continue[i][j];
			++YesCoordY;
		};
	gotoXY(0, 0);
	SetColor();
}

void Menu::DrawNo(int color = 7)
{
	int NoCoordX = 86;
	int NoCoordY = 26; 
	char p = putchar(178);
	
	SetColor(color);
	char Continue[8][11] = 
	{
		{p, ' ', ' ', ' ', p, ' ', ' ', p, p, p, ' '},
		{p, p, ' ', ' ', p, ' ', p, ' ', ' ', ' ', p},
		{p, p, ' ', ' ', p, ' ', p, ' ', ' ', ' ', p},
		{p, ' ', p, ' ', p, ' ', p, ' ', ' ', ' ', p},
		{p, ' ', p, ' ', p, ' ', p, ' ', ' ', ' ', p},
		{p, ' ', ' ', p, p, ' ', p, ' ', ' ', ' ', p},
		{p, ' ', ' ', p, p, ' ', p, ' ', ' ', ' ', p},
		{p, ' ', ' ', ' ', p, ' ', ' ', p, p, p, ' '},
		
	};
	
	for ( int i = 0; i <= PixelHeight -1; ++i )
		{
			SetColor(color);
			gotoXY(NoCoordX,NoCoordY);
			for ( int j = 0; j <= NoWidth - 1; ++j )
				cout << Continue[i][j];
			++NoCoordY;
		}
	gotoXY(0, 0);
	SetColor();
}

void Menu::DrawGameOver(int color = 3)
{
	SetColor(color);
	int GameOverCoordX = 75;
	int GameOverCoordY = 15;
	int GameOverWidth = 23;
	
	char p = putchar(178);
	char Game[8][23] = 
	{
		{' ', p, p, p, ' ', ' ', ' ', ' ', p, ' ', ' ', ' ', p, ' ', ' ', ' ', p, ' ', p , p, p, p, p},
		{p, ' ', ' ', ' ', p, ' ', ' ', p, ' ', p, ' ', ' ', p, p, ' ', p, p, ' ', p, ' ', ' ', ' ', ' ' },
		{p , ' ', ' ', ' ', ' ', ' ', p, ' ', ' ', ' ', p, ' ', p, ' ', p, ' ', p, ' ', p, ' ', ' ', ' ', ' ' },
		{p, ' ', ' ', ' ', ' ', ' ', p, ' ', ' ', ' ', p, ' ', p, ' ', ' ', ' ', p, ' ', p, p, p, p, ' '},
		{p , ' ', p, p, p, ' ', p, p, p, p, p, ' ', p, ' ', ' ', ' ', p, ' ', p, ' ', ' ', ' ', ' ' },
		{p, ' ', ' ', ' ', p, ' ', p, ' ', ' ', ' ', p, ' ', p, ' ', ' ', ' ', p, ' ', p, ' ', ' ', ' ', ' ' },
		{p, ' ', ' ', ' ', p, ' ', p, ' ', ' ', ' ', p, ' ', p, ' ', ' ', ' ', p, ' ', p, ' ', ' ', ' ', ' ' },
		{' ', p, p, p, ' ', ' ', p, ' ', ' ', ' ', p, ' ', p, ' ', ' ', ' ', p, ' ', p, p, p, p, p },
	};
	
		char Over[8][23] = 
	{
		{' ', p, p, p, ' ', ' ', p, ' ', ' ', ' ', p, ' ', p, p, p, p, p, ' ', p, p, p, p, ' '},
		{p, ' ', ' ', ' ', p, ' ', p, ' ', ' ', ' ', p, ' ', p, ' ', ' ', ' ', ' ', ' ', p, ' ', ' ', ' ', p},
		{p, ' ', ' ', ' ', p, ' ', p, ' ', ' ', ' ', p, ' ', p, ' ', ' ', ' ', ' ', ' ', p, ' ', ' ', ' ', p},
		{p, ' ', ' ', ' ', p, ' ', p, ' ', ' ', ' ', p, ' ', p, p, p, p, ' ', ' ', p, p, p, p, ' '},
		{p, ' ', ' ', ' ', p, ' ', p, ' ', ' ', ' ', p, ' ', p, ' ', ' ', ' ', ' ', ' ', p, ' ', p, ' ', ' '},
		{p, ' ', ' ', ' ', p, ' ', p, ' ', ' ', ' ', p, ' ', p, ' ', ' ', ' ', ' ', ' ', p, ' ', ' ', p, ' '},
		{p, ' ', ' ', ' ', p, ' ', ' ', p, ' ', p, ' ', ' ', p, ' ', ' ', ' ', ' ', ' ', p, ' ', ' ', ' ', p},
		{' ', p, p, p, ' ', ' ', ' ', ' ', p, ' ', ' ', ' ', p, p, p, p, p, ' ', p, ' ', ' ', ' ', p },
	};
	
	for ( int i = 0; i <= PixelHeight - 1; ++i )
		{
			gotoXY (GameOverCoordX,GameOverCoordY);
			for ( int j = 0; j <= GameOverWidth -1; ++j )
				cout << Game[i][j];
			++GameOverCoordY;
		};
	
	for ( int i = 0; i <= PixelHeight - 1; ++i )
		{
			gotoXY(GameOverCoordX,GameOverCoordY + Space);
			for ( int j = 0; j <= GameOverWidth - 1; ++j )
				cout << Over[i][j];
			++GameOverCoordY;
		};
}

void Menu::DrawMenuBoard()
{
	clrscr();
	Caro Title(Node,Cell,P1,P2,PvC,MFileName);
	Title.DrawTitle(72,0);
	DrawPlay(2);
	DrawOptions();
	DrawAbout();

	bool y = true;
	int Pre;
	int Current = 0;

	while(y)
	{
		int Key = getch();
		switch (Key) 
			{
				case 13:		//Enter
					y = false;
					break;
				case 72:		//Up
					Pre = Current;
					--Current;
					if ( Current < 0 ) 
						Current = 2;
					break;
				case 80:		// Down
					Pre = Current;
					++Current;
					if ( Current > 2 ) 
						Current = 0;
					break;
			}
		switch (Pre)
			{
				case 0:
					DrawPlay();
					break;
				case 1:
					DrawOptions();
					break;
				case 2:
					DrawAbout();
					break;
			}
		switch (Current)
			{
				case 0:
					DrawPlay(2);
					break;
				case 1:
					DrawOptions(2);
					break;
				case 2:
					DrawAbout(2);
					break;
			}
	}
	switch (Current)
	{
		case 0:
			DrawPvPPvC();
			break;
		case 1:
			Options();
			break;
		case 2:
			break;	
	}
}

void Menu::DrawPvPPvC()
{
		clrscr();
		DrawMode();
		DrawPvP(2);
		DrawPvC(7);
		
		bool y = true;
		int Pre;
		int Current = 0;
		int ESC = 0;
		
		while(y)
		{	
				int Key = getch();
				switch (Key) 
				{
					case 13:		//Enter
						y = false;
						break;
					case 27:
						y = false;
						ESC = 1;
						break;	
					case 72:		//Up
						Pre = Current;
						--Current;
						if ( Current < 0 ) 
							Current = 1;
						break;
					case 80:		// Down
						Pre = Current;
						++Current;
						if ( Current > 1) 
							Current = 0;
						break;
				}
				
				switch (Pre)
				{
					case 0:
						DrawPvP();
						break;
					case 1:
						DrawPvC();
				}
				
				switch (Current)
				{
					case 0:
						DrawPvP(2);
						break;
					case 1:
						DrawPvC(2);
						break;
				}
		}
	if ( ESC == 1 )
	{
		DrawMenuBoard();
	}
	else
	{
		switch (Current)
		{
			case 0:
				break;
			case 1:
				PvC = 1;
				break;
		}
		DrawNewGameBoard();
	}
}

void Menu::DrawNewGameBoard()
{
	clrscr();
	DrawNewGame();
	DrawYes(2);
	DrawNo();
		bool y = true;
		int Pre;
		int Current = 0;
		int ESC = 0;
 	
		while(y)
		{
			int Key = getch();
			switch (Key) 
				{
					case 13:		//Enter
						y = false;
						break;
					case 27:
						y = false;
						ESC = 1;
						break;
					case 72:		//Up
						Pre = Current;
						--Current;
						if ( Current < 0 ) 
							Current = 1;
						break;
					case 80:		// Down
						Pre = Current;
						++Current;
						if ( Current > 1) 
							Current = 0;
						break;
				}
				
				switch (Pre)
				{
					case 0:
						DrawYes();
						break;
					case 1:
						DrawNo();
						break;
				}
			switch (Current)
				{
					case 0:
						DrawYes(2);
						break;
					case 1:
						DrawNo(2);
						break;
				}		
		}
	if ( ESC == 1 )
	{
		DrawPvPPvC();
	} 
	else
		switch(Current)
		{
			case 0:
				break;
			case 1:
				{
					gotoXY(75,38);
					SetColor(2);
					cout << "Write the file you want to load here: ";
					cin >> mFileName;
					Convert(mFileName);
					LoadFile = 1; 
				}
				break;
		} 
}

void Menu::PvP()
{
	P1.Checker = 'X';
	P2.Checker = 'O';
	P1.Color = 7;
	P2.Color = 7;
	
	int Loop = 1; 
	Caro ThiDau(Node, Cell, P1, P2, PvC, MFileName);
	clrscr();
	
			//-- Front end
		ThiDau.DrawBoard();
		switch (LoadFile)	
			{
				case 1:
					{
						ThiDau.ContinueFile(MFileName);
					}
					
					break;
				case 0:
					if (cOptions == 1)
						ThiDau.ContinueFile(MFileName);
					break;			
			}	
		ThiDau.Draw_Caro();	
		ThiDau.PlayerBox();
	
		//-- Back end
		while (Loop)
		{
			Loop = ThiDau.Play();
			
			ThiDau.Draw_Caro();
			
		
			if (Loop !=0)  
			{
				if (ThiDau.IsWinner()) 
				{ 
					switch (ThiDau.PlayUser)
					{
						case 1:
							++ThiDau.U1.Won;
							ThiDau.gotoXY (Cell*CellWidth/3, Cell * CellHeight+1);
							cout  << P1.Name << " WON";
							break;
						case 2:
							++ThiDau.U2.Won;
							ThiDau.gotoXY (Cell*CellWidth/3, Cell * CellHeight+1);
							cout << P2.Name << " WON";
							break;	
					}
					ThiDau.SaveFile(MFileName);
					Loop = 0;
				}
				else
					if (ThiDau.IsDraw())
						{
							ThiDau.gotoXY (Cell*CellWidth/3, Cell * CellHeight+1);
							cout << "DRAW";
							Loop = 0;
						}
					else  
					{
						ThiDau.CheckPvC();
						ThiDau.PlayUser = (ThiDau.PlayUser == 1 ? 2 : 1);
						
					}
			}
			} 
}

  void Menu::CaroPvC()
{
	P1.Checker = 'X';
	P2.Checker = 'O';
	
	P1.Name = "Player 1";
	P2.Name = "Toshi";
	
	P1.Color = 7;
	P2.Color = 13;
	
	int Loop = 1; 
	Caro ThiDau(Node, Cell, P1, P2, PvC, MFileName);
	clrscr();
	ThiDau.DrawBoard();
	switch (LoadFile)
			{
				case 1:
					ThiDau.ContinueFile(MFileName);
					break;
				case 0:
					if (cOptions == 1)
						ThiDau.ContinueFile(MFileName);
					break;			
			}	
	ThiDau.Draw_Caro();	
	
	
	while (Loop)
	{
			Loop = ThiDau.Play();
			ThiDau.Draw_Caro();
			
			if (Loop !=0)  
			{
				if (ThiDau.IsWinner()) 
				{ 
					switch (ThiDau.PlayUser)
					{
						case 1:
							++ThiDau.U1.Won;
							ThiDau.gotoXY (Cell*CellWidth/3, Cell * CellHeight+1);
							cout  << P1.Name << " WON " << P1.Won << " - " << P2.Won;
							break;
						case 2:
							++ThiDau.U2.Won;
							clrscr();
							DrawGameOver();
							break;	
					}
					ThiDau.SaveFile(MFileName);
					Loop = 0;
				}
				else
					if (ThiDau.IsDraw())
						{
							ThiDau.gotoXY (Cell*CellWidth/3, Cell * CellHeight+1);
							cout << "DRAW";
							Loop = 0;
						}
					else  
					{
						ThiDau.PlayUser = (ThiDau.PlayUser == 1 ? 2 : 1);
						if (ThiDau.PlayUser == 2)
						{
								ThiDau.EasyPvC();
								ThiDau.Draw_Caro();
						}
							
					}
			}
	} 
} 


int Menu::CheckInput(int Min, int Max, string S, int X, int Y)
{
	
	char In[1000];
	int Temp;
	bool y = true;
	
	do
	{
		gotoXY(X,Y);
		cout << S;
		fflush(stdin);
		fgets (In, 5, stdin);
		Temp = atoi (In);
		if ((Temp < Min) || (Temp > Max))
			{
				y = false;
				gotoXY (X+S.length(),Y);
				cout << "                           ";
			}
		else
			y = true;
	}
	while (!y);
	
	return Temp;
}

char Menu::PlayerChecker(int Nu)
{
	char Ch;
	switch (Nu)
	{
		case 1:
			Ch = putchar(33);
			break;
		case 2: 
			Ch = putchar(36);
			break;
		case 3:
			Ch = putchar(38);
			break;
		case 4:
			Ch = putchar(64);
			break;
		case 5:
			Ch = putchar(156);
			break;
		case 6:
			Ch = putchar(35);
			break;
		case 7: 
			Ch = putchar(225);
			break;
		case 8:
			Ch = putchar(230);
			break;
	}
	return Ch;
}

void Menu::PlayerInfo()
{	
	string Expand = "Board Cell ( 5 <= N <= 20) ? ";
	clrscr();
	SetColor(2);
	
	// Cell Number Input
	gotoXY(70,10);
	Cell = CheckInput(5,20,Expand,75,13);
	
	gotoXY(75, 14);
	cout << "What will your file name be? ";
	
	fflush(stdin);
    getline(cin, mFileName);
	Convert(mFileName);
	
	Palette();
	Checker();
	
	SetColor(2);
	int Number;
	bool y = true;
	string Vibrant = "What color will your checker be? ";
	string Ref = "What will your checker be? ";
	
	//Player 1
	gotoXY(66,18);
	cout << "Enter Player 1's name: ";
	fflush(stdin);
    getline(cin, P1.Name);
    P1.Color = CheckInput(1,15,Vibrant,66,19);
    P1.nChecker = CheckInput(1,8,Ref,66,20);
    P1.Checker = PlayerChecker(P1.nChecker);
    
    //Player 2
	gotoXY(66, 24);
	cout << "Enter Player 2's name: ";
	fflush(stdin);
    getline(cin, P2.Name);
    P2.Color = CheckInput(1,15,Vibrant,66,25);
    P2.nChecker = CheckInput(1,8,Ref,66,26);
    P2.Checker = PlayerChecker(P2.nChecker);
}

void Menu::Options()
{
	clrscr();
	PlayerInfo();
	Caro mHistory(Node,Cell,P1,P2,PvC, MFileName);
	mHistory.SaveFile(MFileName);
	cOptions = 1;

 	gotoXY (75,38);
 	cout << "PRESS ESC TO GO BACK";
	int Key = getch();
	
	if (Key == 27)
		DrawMenuBoard();
}

char* Menu::Convert(string mFileName)
{
    MFileName = new char [mFileName.size()+1];
    std::copy (mFileName.begin(), mFileName.end(), MFileName);
    MFileName [mFileName.size()] = '\0';
    return strcat(MFileName,tail);
}

void Menu::Start()
{
	DrawMenuBoard();
	if (PvC==1)
		{
			CaroPvC();
		}
	else
		PvP();
}

#endif


