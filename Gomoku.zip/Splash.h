#ifndef _Splash_H_
#define _Splash_H_

#include <iostream>
#include <stdio.h>
#include <conio.h>
#include <windows.h>
#include <cstdlib>
#include <Caro.h>
#define consoleWidth 80
#define consoleHeight 26
#define TitleHeight 5
#define TitleWidth 30

using namespace std;

void PressAnyKey();


void DrawTitle(int x, int y)
{
	while(1)
	{
		for ( int j = 1; j <= TitleHeight; ++j )
		{
			gotoXY(x, y);
			switch (j)
			{
				case 1:
				{
					for ( int i = 1; i <= TitleWidth; ++i )
						if ((i==2)||(i==3)||(i==7)||(i==8)||(i==12)||(i==14)||(i==18)||(i==19))
							putchar(205);
						else
							if ((i==1)||(i==6)||(i==11)||(i==17))
								putchar(201);
							else
								if ((i==9)||(i==20)||(i==15))
									putchar(187);
								else
									if ((i==22)||(i==27)||(i==30))
										putchar(203);
									else
										if (i==13)
											putchar(203);
										else 
											if (i==25) 
												cout << "x";
											else
												cout << " ";
					break;	
				}
	 			case 2:
	 			{
	 				for ( int i = 1; i <= TitleWidth; ++i )
						if (i==24) 
							cout << "0";
						else
							if ((i==1)||(i==6)||(i==9)||(i==11)||(i==13)||(i==15)||(i==17)||(i==20)||(i==22)||(i==27)||(i==30)) 
								putchar(186);
							else
								cout << " ";
					break;
				}
				case 3:
				{
					for ( int i = 1; i <= TitleWidth; ++i )
						if ((i==1)||(i==6)||(i==9)||(i==11)||(i==13)||(i==15)||(i==17)||(i==20)||(i==22)||(i==27)||(i==30))
							putchar(186);
						else
							if (i==4)
								putchar(187);
							else
								if (i==3)
									putchar(205);
								else
									if (i==23)
										cout << "x";
									else
										cout << " ";
					break;
				}	
				case 4:
				{
					for ( int i = 1; i <= TitleWidth; ++i )
						if ((i==1)||(i==4)||(i==6)||(i==9)||(i==11)||(i==15)||(i==17)||(i==20)||(i==22)||(i==27)||(i==30))
							putchar(186);
						else
							if (i==24)
								cout << "0";
							else
								cout << " ";
					break;
				}
				case 5:
				{
					for ( int i = 1; i <= TitleWidth; ++i )
						if ((i==1)||(i==6)||(i==17)||(i==27))
							putchar(200);
						else
							if ((i==4)||(i==9)||(i==20)||(i==30))
								putchar(188);
							else
								if ((i==2)||(i==3)||(i==7)||(i==8)||(i==18)||(i==19)||(i==28)||(i==29))
									putchar(205);
								else
									if ((i==22)||(i==11)||(i==15))
										putchar(202);
									else
										if (i==25)
											cout << "x";
										else 
											
												cout << " ";
					break;
				}
			}
			++y;
		};
		break;
	}
	Sleep(100);
}

void Random()
{
	int h = 0;
	while (h==0)
	{
		int x = (rand() % 150 + TitleWidth);
		int y = (rand() % 25 + TitleHeight);
		DrawTitle(x,y);
		Sleep(200);
		gotoXY (x,y);
		clrscr();
		gotoXY(80,38);
		cout << "PRESS ANY KEY TO CONTINUE...";
		h=kbhit();
	}
}

void CornerDownBottom()
{	
	SetColor(rand() % 15 + 1);
	for (int i = 0; i <= (40 - TitleHeight - 30); ++i)
		{
			DrawTitle(170 - TitleWidth, 0 + 4*i);
			clrscr();
		}	
}

void TopToCorner()
{
	
	SetColor(rand() % 15 + 1);
	for (int i = 0; i <= 170 - TitleWidth - 120; ++i)
		{
			DrawTitle(0 + 7*i , 0);
			clrscr();
		}
	
}

void BottomToCorner()
{
	SetColor(rand() % 15 + 1);
	for (int i = 0; i <= 170 -TitleWidth - 120; ++i)
		{
			DrawTitle(170 - TitleWidth - 7*i, 35);
			clrscr();
		}
	
}

void CornerToTop()
{
	SetColor(rand() % 15 + 1);
	for (int i = 0; i <= 40 - TitleHeight - 30; ++i)
		{
			DrawTitle(0, 40 -TitleHeight - 4*i);
			clrscr();
		}
	
}

void Splash()
{
		TopToCorner();
		CornerDownBottom();
		BottomToCorner();
		CornerToTop();
		Random();
			
	clrscr();
}

#endif
